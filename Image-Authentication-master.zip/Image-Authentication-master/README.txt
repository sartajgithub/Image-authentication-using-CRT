"Image Authentication using Chinese Reaminder Theorem" 
